import org.junit.Test;

import static org.junit.Assert.*;

public class RegularManualTransmissionTest {

  @Test
  public void getStatus() {
  }

  @Test
  public void getSpeed() {
  }

  @Test
  public void getGear() {
  }

  @Test
  public void increaseSpeed() {
  }

  @Test
  public void decreaseSpeed() {
  }

  @Test
  public void increaseGear() {
  }

  @Test
  public void decreaseGear() {
  }
}