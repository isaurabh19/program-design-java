package vehicle;

/**
 * An interface that represents a set of methods used for manual transmission of a vehicle. A manual
 * transmission is the mode of vehicle operation where it's the driver's responsibility to change
 * gear based on the instantaneous speed of car.
 */
public interface ManualTransmission {
  /**
   * A method that returns the current transmission status of the car.
   * @return a status message of the current status as string.
   */
  String getStatus();

  /**
   * A method that returns the current speed of the car.
   * @return the speed of the car as a whole number.
   */
  int getSpeed();

  /**
   * A method that returns the current gear that car is in.
   * @return gear of the car as a whole number.
   */
  int getGear();

  /**
   * A method to increase the speed of a car by a pre determined fix amount.
   * @return a ManualTransmission object.
   */
  ManualTransmission increaseSpeed();

  /**
   *
   * @return
   */
  ManualTransmission decreaseSpeed();

  /**
   *
   * @return
   */
  ManualTransmission increaseGear();

  /**
   *
   * @return
   */
  ManualTransmission decreaseGear();
}
