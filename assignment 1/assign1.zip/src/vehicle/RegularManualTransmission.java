package vehicle;


import java.util.HashMap;

public class RegularManualTransmission implements ManualTransmission{

  private int currentSpeed;
  private int currentGear;
  private int maxSpeed;
  private String currentStatusMessage;
  private final int speedChange = 1;//TODO: use static?
  private final int maxGears = 5;
  private HashMap<Integer, Integer[]> gearRange = new HashMap<Integer,Integer[]>();;//TODO: find an immutable array type.
  private int l1,h1,l2,h2,l3,h3,l4,h4,l5,h5;

  public RegularManualTransmission (int l1, int h1, int l2, int h2,int l3, int h3, int l4, int h4,
                                    int l5, int h5) throws IllegalArgumentException {
    if(!((l1<l2)&&(l2<l3)&&(l3<l4)&&(l4<l5))) {
      throw new IllegalArgumentException();
    }
    if((l1>h1)|| (l2>h2) || (l3>h3) || (l4>h4) || (l5>h5) ) {
      throw new IllegalArgumentException();
    }
    // if adjacent ranges don't overlap, throw exception
    if((h1<l2) || (h2<l3) || (h3<l4) || (h4<l5)){
      throw new IllegalArgumentException();
    }

    this.gearRange.put(1,new Integer[]{0,h1});
    this.gearRange.put(2, new Integer[] {l2,h2});
    this.gearRange.put(3, new Integer[]{l3,h3});
    this.gearRange.put(4, new Integer[]{l4,h4});
    this.gearRange.put(5, new Integer[]{l5,h5});
    this.maxSpeed = h5;
    this.currentStatusMessage = "OK: everything is OK.";
    this.currentGear = 1;
    this.currentSpeed = 0;
//    this.l1 = 0;
//    this.h1 = h1;
//    this.l2 = l2;
//    this.h2 = h2;
//    this.l3 = l3;
//    this.h3 = h3;
//    this.l4 = l4;
//    this.h4 = h4;
//    this.l5 = l5;
//    this.h5 = h5;
  }

  private RegularManualTransmission(HashMap<Integer,Integer[]> gearRange,
                                    String currentStatusMessage, int currentSpeed,
                                    int currentGear, int maxSpeed ) {
    this.gearRange = gearRange;
    this.currentStatusMessage = currentStatusMessage;
    this.currentSpeed = currentSpeed;
    this.currentGear = currentGear;
    this.maxSpeed = maxSpeed;

  }
  @Override
  public String getStatus() {
    return this.currentStatusMessage;
  }

  @Override
  public int getSpeed() {
    return this.currentSpeed;
  }

  @Override
  public int getGear() {
    return this.currentGear;
  }

  @Override
  public ManualTransmission increaseSpeed() {

    if(this.currentSpeed + this.speedChange > this.maxSpeed) {
      this.currentStatusMessage = "Cannot increase speed. Reached maximum speed.";
    }
    else if(this.currentGear == this.maxGears ) {
      this.currentSpeed = this.currentSpeed + this.speedChange;
      this.currentStatusMessage = "OK: everything is OK.";
    }
    else if ((this.currentSpeed + this.speedChange >= this.gearRange.get(this.currentGear + 1)[0])
            &&((this.currentSpeed + this.speedChange) <= this.gearRange.get(this.currentGear)[1])){
      this.currentSpeed = this.currentSpeed + this.speedChange;
      this.currentStatusMessage = "OK: you may increase the gear.";
    }
    else if(this.currentSpeed + this.speedChange > this.gearRange.get(this.currentGear)[1]){
      this.currentStatusMessage = "Cannot increase speed, increase gear first.";
    }
    else{
      this.currentSpeed = this.currentSpeed + this.speedChange;
      this.currentStatusMessage = "OK: everything is OK.";
    }
    return new RegularManualTransmission(gearRange,this.currentStatusMessage,this.currentSpeed,
            this.currentGear, this.maxSpeed);
  }

  @Override
  public ManualTransmission decreaseSpeed() {
    if(this.currentSpeed - this.speedChange < 0) {
      this.currentStatusMessage = "Cannot decrease speed. Reached minimum speed.";
    }
    else if(this.currentGear == 1) {
      this.currentSpeed = this.currentSpeed - 1;
      this.currentStatusMessage = "OK: everything is OK.";
    }
    else if((this.currentSpeed - this.speedChange <= this.gearRange.get(this.currentGear - 1)[1])
            && (this.currentSpeed - this.speedChange >= this.gearRange.get(this.currentGear)[0])) {
      this.currentSpeed = this.currentSpeed - this.speedChange;
      this.currentStatusMessage = "OK: you may decrease the gear.";
    }
    else if(this.currentSpeed - this.speedChange < this.gearRange.get(this.currentGear)[0]){
      this.currentStatusMessage = "Cannot decrease speed, decrease gear first.";
    }
    else{
      this.currentSpeed = this.currentSpeed - this.speedChange;
      this.currentStatusMessage = "OK: everything is OK.";
    }
    return new RegularManualTransmission(this.gearRange,this.currentStatusMessage,this.currentSpeed,
            this.currentGear, this.maxSpeed);
  }

  @Override
  public ManualTransmission increaseGear() {
    if(this.currentGear == this.maxGears) {
      this.currentStatusMessage = "Cannot increase gear. Reached maximum gear.";
    }
    else if(this.currentSpeed >= this.gearRange.get(this.currentGear + 1)[0]) {
      this.currentGear = this.currentGear + 1;
      this.currentStatusMessage = "OK: everything is OK.";
    }
    else if(this.currentSpeed < this.gearRange.get(this.currentGear + 1)[0]) {
      this.currentStatusMessage = "Cannot increase gear, increase speed first.";
    }
    return new RegularManualTransmission(this.gearRange,this.currentStatusMessage,this.currentSpeed,
            this.currentGear, this.maxSpeed);
  }

  @Override
  public ManualTransmission decreaseGear() {
    if(this.currentGear == 1) {
      this.currentStatusMessage = "Cannot decrease gear. Reached minimum gear.";
    }
    else if(this.currentSpeed <= this.gearRange.get(this.currentGear - 1)[1]) {
      this.currentGear = this.currentGear - 1;
      this.currentStatusMessage = "OK: everything is OK.";
    }
    else if(this.currentSpeed > this.gearRange.get(this.currentGear - 1)[1]) {
      this.currentStatusMessage = "Cannot decrease gear, decrease speed first.";
    }
    return new RegularManualTransmission(this.gearRange,this.currentStatusMessage,this.currentSpeed,
            this.currentGear, this.maxSpeed);
  }
}
