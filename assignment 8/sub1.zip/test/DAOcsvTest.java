import org.junit.Test;

import java.time.LocalDateTime;

import stock.model.IPortfolio;
import stock.model.PortfolioImpl;

public class DAOcsvTest {
  @Test
  public void test() {
    IPortfolio testIPortfolio = new PortfolioImpl("Nachiket1");
    testIPortfolio.add("GOOG", 5000.24d,
            LocalDateTime.of(2017, 1, 10, 10, 0));
    System.out.println(testIPortfolio.toString());
    testIPortfolio.add("MSFT", 5000.24d,
            LocalDateTime.of(2017, 1, 10, 14, 0));
    System.out.println(testIPortfolio.toString());
    testIPortfolio.add("AMZN", 8800.24d,
            LocalDateTime.of(2017, 2, 3, 9, 0));
    System.out.println(testIPortfolio.toString());

    System.out.println("Value on 7 May 2018:"
            + testIPortfolio.getValueByDate
            (LocalDateTime.of(2018, 11, 13, 9, 0)));
    System.out.println("Cost Basis: " + testIPortfolio.getCostBasis());


    //System.out.println(testIPortfolio.toString());
    //System.out.println(testIPortfolio.toString());
    //System.out.println(testIPortfolio.getValueByDate(LocalDateTime.of(2018, 5, 7, 9, 0)));
    //System.out.println(testIPortfolio.getPortfolioName());
    //testIPortfolio.add("MSFT", 1500.24d, LocalDateTime.of(2014, 2, 3, 9, 0));
  }
}