package stock.model.dao;

import java.io.File;
import java.io.FileNotFoundException;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

import stock.model.IStock;
import stock.model.StockImpl;

/**
 * Works on past not real time.
 */
//todo write documentation.
public class DAOcsv<T> extends DAOAbstract {

  @Override
  public Map<IStock, Integer> buyStockFromMarket(String tickerSymbol, Double amount,
                                                 LocalDateTime dateOfPurchase) {
    Double closingAmount = valueOfStockOnDate(tickerSymbol, dateOfPurchase);
    Map<IStock, Integer> tempMap = new LinkedHashMap<>();
    tempMap.put(new StockImpl(tickerSymbol, closingAmount, dateOfPurchase),
            numberOfStocksBought(closingAmount, amount));
    return tempMap;
  }

  private String[] fetchStockData(String tickerSymbol, LocalDateTime date) {
    String strDateOfPurchase = getDateInFormat(date);
    try {
      Scanner scan = new Scanner(new File("stockInfo/" + tickerSymbol + ".csv"));
      scan.useDelimiter("\n");
      while (scan.hasNext()) {
        String line = scan.next();
        if (line.contains(strDateOfPurchase)) {
          return line.split(",");
        }
      }
    } catch (FileNotFoundException e) {
      throw new IllegalArgumentException("Enter valid ticker symbol.\n");
    }
    throw new IllegalArgumentException("Enter valid date.\n");
  }

  @Override
  public Double valueOfStockOnDate(String tickerSymbol, LocalDateTime date) {
    String[] stockData = fetchStockData(tickerSymbol, date);
    String strClosingAmt = stockData[4];
    return Double.parseDouble(strClosingAmt);
  }
}
