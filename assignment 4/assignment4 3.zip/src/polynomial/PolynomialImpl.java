package polynomial;

import java.util.Objects;
import java.util.Scanner;

public class PolynomialImpl implements Polynomial {
  private ListADTNode<PolynomialTerm> head;

  private PolynomialImpl(ListADTNode<PolynomialTerm> node) {
    this.head = node;
  }

  public PolynomialImpl() {
    head = new ListADTElementNode<>(new PolynomialTerm(0, 0),
            new ListADTEmptyNode<>());
  }

  public PolynomialImpl(String expression) {
    head = new ListADTElementNode<>(new PolynomialTerm(0, 0),
            new ListADTEmptyNode<>());
    Scanner scanner = new Scanner(expression);
    int coefficient;
    int power;
    while (scanner.hasNext()) {
      String terms[] = scanner.next().split("[xX]\\^");
      if (!terms[0].isEmpty()) {
        try {
          coefficient = Integer.parseInt(terms[0]);
        } catch (NumberFormatException e) {
          if (terms[0].equals("-")) {
            coefficient = -1;
          } else if (terms[0].equals("+")) {
            coefficient = 1;
          } else {
            throw new IllegalArgumentException("Invalid term in coefficient");
          }
        }
      } else {
        coefficient = 1;
      }
      if (terms.length == 1) {
        power = 0;
      } else {
        try {
          power = Integer.parseInt(terms[1]);
        } catch (NumberFormatException e) {
          throw new IllegalArgumentException("Invalid term in power");
        }
      }
      addTerm(coefficient, power);
    }
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.toString());
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (!(obj instanceof Polynomial)) {
      return false;
    }
    Polynomial polynomial = (Polynomial) obj;
    return this.toString().equals(polynomial.toString());
  }

  @Override
  public String toString() {
    //ListADTNode<String> strings = this.head.map(term -> term.toString());
    String polynomial = this.head.toString().trim();
    if (polynomial.isEmpty()) {
      return "0";
    }
    if (polynomial.charAt(0) == '+') {
      polynomial = polynomial.substring(1);
    }
    return polynomial;
  }

  @Override
  public void addTerm(int coefficient, int power) {
    if (power < 0) {
      throw new IllegalArgumentException("Negative powers are not allowed");
    }
    PolynomialTerm term = new PolynomialTerm(coefficient, power);
    this.head = this.head.addTerm(term);
  }

  @Override
  public int getDegree() {
    return this.head.getDegree();
  }

  @Override
  public int getCoefficient(int power) {
    return this.head.getCoefficient(power);
  }

  @Override
  public double evaluate(double variable) {
    return this.head.reduce(0.0,(a,b) -> a + b.evaluate(variable) );
    //return this.head.evaluate(variable);
  }

  @Override
  public Polynomial add(Polynomial polynomial) {
    if (polynomial instanceof PolynomialImpl) {
      return new PolynomialImpl(this.head.add(((PolynomialImpl) polynomial).head));
    }
    throw new IllegalArgumentException("");
  }

  @Override
  public Polynomial derivative() {
    return new PolynomialImpl(this.head.map(PolynomialTerm::derivative));
  }
}
