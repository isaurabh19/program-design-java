package polynomial;

import java.util.function.BiFunction;
import java.util.function.Function;

public class ListADTEmptyNode<T> implements ListADTNode<T> {

  @Override
  public ListADTNode<T> addTerm(PolynomialTerm term) {
    return new ListADTElementNode(term, new ListADTEmptyNode());
  }

  @Override
  public <R> ListADTNode<PolynomialTerm> map(Function<PolynomialTerm, PolynomialTerm> converter) {
    return new ListADTEmptyNode<>();
  }

  @Override
  public int getCoefficient(int power) {
    return 0;
    //throw new IllegalArgumentException("Power does not exist");
  }

  @Override
  public int getDegree() {
    return 0;
  }

//  @Override
//  public ListADTNode<T> map(Function converter) {
//    return new ListADTEmptyNode<>();
//  }

  @Override
  public String toString() {
    return "";
  }

  @Override
  public double evaluate(double value) {
    return 0;
  }

  @Override
  public String toStringHelper(String accumulated) {
    return accumulated;
  }

  @Override
  public double evaluateHelper(double accumulated, double value) {
    return accumulated;
  }

  @Override
  public ListADTNode add(ListADTNode head) {
    return new ListADTElementNode(head.getTerm(), head.getRest());
  }

  @Override
  public PolynomialTerm getTerm() {
    return new PolynomialTerm(0, 0);
  }

  @Override
  public <R> R reduce(R init, BiFunction<R, PolynomialTerm, R> biFunction) {
    return init;
  }

  @Override
  public ListADTNode getRest() {
    return new ListADTEmptyNode();
  }
}
