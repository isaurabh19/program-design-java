package polynomial;

public interface Polynomial {
  void addTerm(int coefficient, int power);

  int getDegree();

  int getCoefficient(int power);

  double evaluate(double variable);

  Polynomial add(Polynomial polynomial);

  Polynomial derivative();
}
