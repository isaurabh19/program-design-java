package polynomial;

import java.util.function.BiFunction;
import java.util.function.Function;

public interface ListADTNode<T> {
  ListADTNode<T> addTerm(PolynomialTerm term);

  <R> ListADTNode<PolynomialTerm> map(Function<PolynomialTerm, PolynomialTerm> converter);

  //<R> ListADTNode<R> map(Function<PolynomialTerm,R> conv);

  int getCoefficient(int power);

  int getDegree();

  String toString();

  double evaluate(double value);

  String toStringHelper(String accumulated);

  double evaluateHelper(double accumulated, double value);

  <R>ListADTNode<R> add(ListADTNode head);

  PolynomialTerm getTerm();

  <R>ListADTNode<R> getRest();
  <R> R reduce(R init, BiFunction<R, PolynomialTerm, R> biFunction);
}
