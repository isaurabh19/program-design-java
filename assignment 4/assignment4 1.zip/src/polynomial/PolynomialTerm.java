package polynomial;

public class PolynomialTerm {
  private final int coefficient;
  private final int power;
  private final String variable = "x^";

  public PolynomialTerm(int coefficient, int power){
    this.coefficient = coefficient;
    this.power = power;
  }

  public int getCoefficient(){
    return this.coefficient;
  }
  public int getPower(){
    return this.power;
  }

  @Override
  public String toString() {
    String coefficientString = coefficient + "";
    String powerString = power + "";
    String variableString = variable;
    if(coefficient == 0){
      coefficientString = "";
      powerString = "";
      variableString = "";
    }
    else if(coefficient>0){
      coefficientString = "+"+coefficient;
    }
    if(power <= 0){
      powerString = "";
      variableString = "";
    }
    return coefficientString+variableString+powerString;
  }
  public double evaluate(double value){
    if(power == 0){
      return coefficient;
    }
    return coefficient * Math.pow(value,power);
  }
  public PolynomialTerm derivative(){
    int newPower = power;
    int newCoefficient = coefficient;
    if(power > 0){
      newCoefficient *= newPower;
      newPower -= 1;
    }
    if(power == 0){
      newCoefficient = 0;
    }
    return new PolynomialTerm(newCoefficient,newPower);
  }
}
