package polynomial;

abstract class AbstractListADTNode implements ListADTNode {
  @Override
  abstract public ListADTNode addTerm(PolynomialTerm term);

  @Override
  abstract public int getCoefficient(int power);

  @Override
  abstract public int getDegree();

  @Override
  abstract public double evaluate(double value);


//  abstract protected String toStringHelper(String accumulated);
//  abstract  protected double evaluateHelper(double value);
}
