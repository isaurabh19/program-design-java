package polynomial;

import java.util.function.Function;

public interface ListADTNode<T> {
  ListADTNode<T> addTerm(PolynomialTerm term);

  <R> ListADTNode<PolynomialTerm> map(Function<PolynomialTerm, PolynomialTerm> converter);

  int getCoefficient(int power);

  int getDegree();

  String toString();

  double evaluate(double value);

  String toStringHelper(String accumulated);

  double evaluateHelper(double accumulated, double value);

  ListADTNode add(ListADTNode head);

  PolynomialTerm getTerm();

  ListADTNode getRest();
  //double reduce(BiFunction<PolynomialTerm,PolynomialTerm,Double> biFunction);
}
