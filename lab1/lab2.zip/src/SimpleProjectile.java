
/**
 * This class represents a Newtonian particle. A particle has an initial x,y position and an initial
 * horizonatal and vertical velocity vx, vy respectively.
 */
public class SimpleProjectile implements Particle {
  private double initial_x;
  private double initial_y;
  private double initial_vx;
  private double initial_vy;
  private final double ACCELARATION = 9.81f;

  /**
   * Construct a particle that has the provided initial positions x,y and initial velocities vx,vy.
   * @param initial_x Initial X co-ordinate position of the particle.
   * @param initial_y Initial Y co-ordinate position of the particle.
   * @param initial_vx Initial horizontal velocity of the particle.
   * @param initial_vy Initial vertical velocity of the particle.
   */

  public SimpleProjectile(double initial_x, double initial_y, double initial_vx, double initial_vy){
    this.initial_x=initial_x;
    this.initial_y=initial_y;
    this.initial_vx=initial_vx;
    this.initial_vy=initial_vy;
  }
  /**
   * Return the state of this particle as a formatted string. The format of the string is as
   * follows:
   * <code>At time [t]: position is ([x],[y])</code> where
   * <ul>
   * <li>[t] is the time passed to this method, rounded to three decimal
   * places</li>
   * <li>[x] is the x-coordinate of the position of this particle at this
   * time, rounded to three decimal places </li>
   * <li>[y] is the y-coordinate of the position of this particle at this
   * time, rounded to three decimal places
   * </li> </ul>
   *
   * @param time the time at which the state must be obtained
   * @return the state of the particle as a string formatted as above
   */
  @Override
  public String getState(float time) {
    double displacement_x, displacement_y;

    displacement_x=this.initial_vx*time;
    displacement_y=this.initial_vy*time - (this.ACCELARATION*0.5*Math.pow(time,2));

    if(time<=0.0 || displacement_y<0.0){
      return String.format("At time [%.2f]: position is ([%.2f],[%.2f])",time,this.initial_x,
              this.initial_y);
    }
    return String.format("At time [%.2f]: position is ([%.2f],[%.2f])",time,
            this.initial_x+displacement_x,this.initial_y+displacement_y);
  }
}
