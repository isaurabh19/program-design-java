import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.assertArrayEquals;

/**
 * Tests to check object arrays can be maintained in proper order.
 */
public class AbstractQuestionTest {

  private Question questionYN1;
  private Question questionLK1;
  private Question questionMC1;
  private Question questionMA1;
  private Question questionYN2;
  private Question questionLK2;
  private Question questionMC2;
  private Question questionMA2;

  /**
   * Sets up multiple objects of all question types.
   */
  @Before
  public void setUp() {
    questionYN1 = new YesNoQuestion("Is sun a star?", YesNoQuestion.Choices.YES);
    questionLK1 = new LikertQuestion("Growth mindset leads to better personality");
    questionMA1 = new MultipleAnswerQuestion("Which of these are moons of Jupiter ?",
            "1 3 4", new String[]{"Europa", "Titan", "Io", "Callisto", "Mimas"});
    questionMC1 = new MultipleChoiceQuestion("Which is the third planet in our solar" +
            " system?", "1", new String[]{"Earth", "Mars", "Jupiter"});
    questionYN2 = new YesNoQuestion("Is earth flat?", YesNoQuestion.Choices.NO);
    questionLK2 = new LikertQuestion("Money can buy happiness");
    questionMA2 = new MultipleAnswerQuestion("Who among these are mammals?",
            "1 2", new String[]{"Humans", "Monkeys", "Chicken"});
    questionMC2 = new MultipleChoiceQuestion("which vitamin do we get from sunlight?",
            "08 ", new String[]{"A1", "B8", "C", "B12", "B9", "B10", "K", "D",});
  }

  @Test
  public void testArraySort() {
    Question[] questionBank = {questionMA1, questionYN1, questionMC2, questionLK2, questionLK1,
            questionMA2, questionYN2, questionMC1, questionYN2};
    Arrays.sort(questionBank);
    String[] sortedQuestionBank = new String[questionBank.length];
    for (int counter = 0; counter < sortedQuestionBank.length; counter++) {
      sortedQuestionBank[counter] = questionBank[counter].getQuestionText();
    }
    assertArrayEquals(sortedQuestionBank, new String[]{"Is earth flat?", "Is earth flat?", "Is sun " +
            "a star?", "Growth mindset leads to better personality", "Money can buy happiness",
            "Which is the third planet in our solar system?", "which vitamin do we get from " +
            "sunlight?", "Which of these are moons of Jupiter ?", "Who among these are mammals?"});
  }
}