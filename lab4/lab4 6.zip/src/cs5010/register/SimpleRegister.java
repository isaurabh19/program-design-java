package cs5010.register;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

public class SimpleRegister implements CashRegister {

  private Map<Integer,Integer> register;
  private List<String> auditLogs = new ArrayList<>();
  //private StringBuilder auditLogs = new StringBuilder();

  public SimpleRegister(){
    register = new TreeMap<>(Collections.reverseOrder());
  }
  private boolean isNumValid(int num){
    if(num < 0){
      throw new IllegalArgumentException("Negative count not allowed");
    }
    return num>0;
  }
  private void addToAuditLogs(int num,String transactionType){
    int dollars = num/100;
    int cents = num%100;
    auditLogs.add(String.format("%s: %d.%02d",transactionType,dollars,cents ));
  }
  @Override
  public void addPennies(int num) throws IllegalArgumentException{
    if(isNumValid(num)){
      register.put(1,num);
      addToAuditLogs(num,"Deposit");
    }
  }

  @Override
  public void addNickels(int num) {
    if(isNumValid(num)){
      register.put(5,num);
      addToAuditLogs(5*num,"Deposit");
    }
  }

  @Override
  public void addDimes(int num) {
    if(isNumValid(num)){
      register.put(10,num);
      addToAuditLogs(10*num,"Deposit");
    }
  }

  @Override
  public void addQuarters(int num) {
    if(isNumValid(num)){
      register.put(25,num);
      addToAuditLogs(25*num,"Deposit");
    }
  }

  @Override
  public void addOnes(int num) {
    if(isNumValid(num)){
      register.put(100,num);
      addToAuditLogs(100*num,"Deposit");
    }
  }

  @Override
  public void addFives(int num) {
    if(isNumValid(num)){
      register.put(500,num);
      addToAuditLogs(500*num,"Deposit");
    }
  }

  @Override
  public void addTens(int num) {
    if(isNumValid(num)){
      register.put(1000,num);
      addToAuditLogs(1000*num,"Deposit");
    }
  }

  private void filterRegister(List<Integer> removeKeys){
    for(Integer key: removeKeys){
      register.remove(key);
    }
  }

  @Override
  public Map<Integer, Integer> withdraw(int dollars, int cents) throws InsufficientCashException {
    Map<Integer,Integer> cashReturn = new TreeMap<>(Collections.reverseOrder());
    Map<Integer,Integer> newRegister = new TreeMap<>(Collections.reverseOrder());
    int amount = 100*dollars + cents;
    List<Integer> removeKeys = new ArrayList<>();
    for(Map.Entry<Integer,Integer> entry: register.entrySet()){
      int denomination = entry.getKey();
      int numberOfDenomination = amount/denomination;
      if(numberOfDenomination > 0) {
        if (numberOfDenomination < entry.getValue()) {
          amount -= numberOfDenomination * denomination;
          cashReturn.put(denomination, numberOfDenomination);
          newRegister.put(denomination,entry.getValue()-numberOfDenomination);
          //entry.setValue(entry.getValue()-numberOfDenomination);
        }
        else {
          amount -= denomination*entry.getValue();
          cashReturn.put(denomination,entry.getValue());
          //entry.setValue(0);
          removeKeys.add(entry.getKey());
        }
      }
      else{
        newRegister.put(entry.getKey(),entry.getValue());
      }
      if(amount == 0){
        break;
      }
    }
    if(amount > 0){
      throw new InsufficientCashException("Insufficient cash");
    }
    filterRegister(removeKeys);
    addToAuditLogs(dollars*100+cents,"Withdraw");
    this.register = newRegister;
    return cashReturn;
  }

  @Override
  public Map<Integer, Integer> getContents() {
    return new TreeMap<>(this.register);
  }

  @Override
  public String getAuditLog() {
    //check if last \n is to be removed.
    return String.join("\n", auditLogs);
  }
}
