import org.junit.Before;
import org.junit.Test;

import java.net.Inet4Address;
import java.util.Map;

import cs5010.register.CashRegister;
import cs5010.register.InsufficientCashException;
import cs5010.register.SimpleRegister;

import static org.junit.Assert.*;

public class SimpleRegisterTest {

  private CashRegister register;

  @Before
  public void setRegister(){
    register = new SimpleRegister();
  }
  @Test
  public void testAddPenniesZeroOnEmptyRegister(){
    register.addPennies(0);
    Map<Integer,Integer> registerMap = register.getContents();
    assertFalse(registerMap.containsKey(1));
  }
  @Test
  public void testAddPenniesZeroOnNonEmptyRegister(){
    register.addPennies(5);
    register.addPennies(0);
    Map<Integer,Integer> registerMap = register.getContents();
    assertTrue(registerMap.containsKey(1));
    if(registerMap.containsKey(1)) {
      int actual = registerMap.get(1);
      assertEquals(5,actual);
    }
    else {
      fail("Key Doesnt exist, test failed");
    }
  }
  @Test(expected = IllegalArgumentException.class)
  public void testAddPenniesNegative(){
    register.addPennies(-1);
  }

  @Test
  public void testAddPenniesOnEmptyRegister(){
    register.addPennies(5);
    Map<Integer,Integer> registerMap = register.getContents();
    if(registerMap.containsKey(1)) {
      int actual = registerMap.get(1);
      assertEquals(5,actual);
    }
    else {
      fail("Key doesn't exist, test failed");
    }
  }

  @Test
  public void testAddPenniesOnNonEmptyRegister(){
    register.addPennies(100);
    register.addPennies(4);
    Map<Integer,Integer> registerMap = register.getContents();
    if(registerMap.containsKey(1)) {
      int actual = registerMap.get(1);
      assertEquals(104,actual);
    }
    else {
      fail("Key Doesnt exist, test failed");
    }
  }
  //TODO repeat the above tests for addNickles,addDimes, addQuarters, addOnes, addFives, addTens
  // and also call audit logs after each addition.
  @Test
  public void testAddTens(){
    register.addTens(12);
    assertEquals("Deposit: 120.00",register.getAuditLog());
  }
  @Test
  public void testGetContentsOnEmptyRegister(){
    Map<Integer,Integer> registerContents = register.getContents();
    assertTrue(registerContents.isEmpty());
  }
  @Test
  public void testGetContentsOnNonEmptyRegister(){
    register.addPennies(3);
    register.addDimes(4);
    register.addOnes(10);
    register.addOnes(0);
    register.addTens(0);
    int [] keys = new int[]{100,10,1};
    int [] values = new int[]{10,4,3};
    Map<Integer,Integer> registerContents = register.getContents();
    for(int i=0;i<keys.length;i++){
      assertTrue(registerContents.containsKey(keys[i]));
      int actual = registerContents.get(keys[i]);
      assertEquals(values[i],actual);
    }
  }
  @Test
  public void testGetContentsOnFullRegister(){

  }


  @Test
  public void testWithdrawAmountLessThanHighest(){
    register.addTens(10);
    register.addFives(5);
    register.addOnes(3);
    register.addQuarters(4);
    register.addDimes(2);
    register.addNickels(3);
    int [] addedCashCount = new int[]{10,5,3,4,2,3};
    int [] addedDenomination = new int[]{1000,500,100,25,10,5};
    StringBuilder auditLog = new StringBuilder();
    for(int i = 0; i<addedCashCount.length; i++){
      int value = addedDenomination[i]*addedCashCount[i];
      auditLog.append(String.format("Deposit: %d.%02d\n",value/100,value%100));
    }
    int [] returnDenomination = new int[]{100,25,10,5};
    int [] returnNumbers = new int[]{3,4,2,2};
    int counter = 0;
    try {
      Map<Integer, Integer> returnSlip = register.withdraw(4, 30);
      for(Map.Entry<Integer,Integer> entry: returnSlip.entrySet()){
        assertEquals(returnDenomination[counter]+":"+returnNumbers[counter],
                entry.getKey()+":"+entry.getValue());
        counter++;
      }
    }
    catch (InsufficientCashException e){
      fail("Test should have passed");
    }
    int [] remainingDenomination = new int[]{5,500,1000};
    int [] remainingCount = new int[]{1,5,10};
    counter = 0;
    for(Map.Entry<Integer,Integer> entry: register.getContents().entrySet()){
      assertEquals(remainingDenomination[counter]+":"+remainingCount[counter],
              entry.getKey()+":"+entry.getValue());
      counter++;
    }
    assertEquals(auditLog.append("Withdraw: 4.30").toString(),register.getAuditLog());
  }
  @Test
  public void testWithdrawAmountMoreThanHighest(){
    register.addTens(10);
    register.addFives(5);
    register.addOnes(3);
    register.addQuarters(4);
    register.addDimes(2);
    register.addNickels(3);
    register.addPennies(9);
    int [] returnDenomination = new int[]{1000,100,25,10,1};
    int [] returnNumbers = new int[]{1,1,1,1,4};
    try {
      Map<Integer, Integer> returnSlip = register.withdraw(11, 39);
      int counter = 0;
      for(Map.Entry<Integer,Integer> entry: returnSlip.entrySet()){
        assertEquals(returnDenomination[counter]+":"+returnNumbers[counter],
                entry.getKey()+":"+entry.getValue());
        counter++;
      }
    }
    catch (InsufficientCashException e){
      fail("Test should have passed");
    }
  }

  @Test(expected = InsufficientCashException.class)
  public void testWithdrawInsufficientCash(){

  }

  @Test
  public void testWithdrawSuccessively(){

  }
}