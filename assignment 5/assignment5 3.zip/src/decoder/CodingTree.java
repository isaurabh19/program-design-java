package decoder;

public interface CodingTree {

  CodingTree addCode(char character, String symbol, int indexOfSymbol);

  LeafMeta decode(String encodedString, int indexAt);

  String allCodes(String accumulator);

  boolean isCodeComplete(int codingSymbolSize);
}
