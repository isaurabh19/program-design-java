package decoder;

public interface Decoder {

  void addCode(char symbol, String code) throws IllegalStateException;

  String decode(String encodedString) throws IllegalStateException;

  String allCodes();

  boolean isCodeComplete();
}
