import org.junit.Before;
import org.junit.Test;

import decoder.Decoder;
import decoder.DecoderImpl;

import static org.junit.Assert.*;

public class DecoderImplTest {

  private Decoder decoder;
  private Decoder hexDecoder;
  private Decoder threeSymbolDecoder;

  @Before
  public void setup(){
   decoder = new DecoderImpl("01");
   hexDecoder = new DecoderImpl("12345678ABCDEF");
  }

  @Test
  public void testDuplicateCodingSymbols(){

  }
  @Test
  public void testDecoderCreation(){

  }

  @Test(expected = IllegalStateException.class)
  public void testAddCodeIllegalCodeSymbol(){
    decoder.addCode('a',"1012");
  }

  @Test
  public void testFirstCodeAddCode(){

  }
  @Test
  public void testAddCode(){

  }

  @Test
  public void testAddCodeSameBranch(){
    //100 , 101
    // 123bcd 123bce
    //123bc1 123bc2
  }
  public void testAddCodeNewBranch(){
    //100 101
    //abcd abdd
    //88f 8af
  }
  @Test
  public void testAddCodeSameCodeNewSymbol(){

  }

  @Test
  public void testSingleElementCodeAddCode(){
    // a->0
    //0->a
  }
  @Test
  public void testDecodeSingleElementCode(){
    //0
  }
  @Test
  public void testDecode(){

  }

  @Test(expected = IllegalStateException.class)
  public void testDecodeIncompleteCode(){
    // reached a node (incomplete message)
    //code doesnt exist in the tree
  }

  @Test(expected = IllegalStateException.class)
  public void testDecodeCodeNotExist(){
    //tree -> 1011
    //message -> 1010 doesn't exist
  }
  @Test(expected = IllegalStateException.class)
  public void testDecodeEmptyCode(){
  //null as well
  }
  @Test(expected = IllegalStateException.class)
  public void testDecodeOnEmptyTree(){

  }
// write test for illegal argument of decode()? e.g illegal char out of symbols?

  @Test
  public void testDecodeExistInIncompleteTree(){

  }

  @Test
  public void testIsCodeComplete(){

  }
  @Test
  public void testIsCodeCompleteSingleChild(){

  }
  @Test
  public void testIsCodeCompleteOneIncomplete(){

  }
  @Test
  public void testIsCodeCompleteFirstLevel(){

  }
  @Test
  public void testIsCodeCompleteMidLevel(){

  }
  @Test
  public void testIsCodeCompleteLastLevel(){

  }
}