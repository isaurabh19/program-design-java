package decoder;

public interface CodingTree {

  CodingTree addCode(char character, String symbol);

  String decode(String encodedString);

  String allCodes(String accumulator);

  boolean isCodeComplete(int codingSymbolSize);
}
