package decoder;

import java.util.HashSet;
import java.util.Set;

public class DecoderImpl implements Decoder {
  private CodingTree root;
  private Set<Character>  codingSymbol;
  public DecoderImpl(String codingSymbols){
    codingSymbol = new HashSet<>();
    for(int i=0;i<codingSymbols.length();i++){
      codingSymbol.add(codingSymbols.charAt(i));
    }
    root = new Node();
  }
  @Override
  public void addCode(char characrterSymbol, String code) throws IllegalStateException {
    for(int i=0;i<code.length();i++) {
      if(!this.codingSymbol.contains(code.charAt(i))){
        throw new IllegalStateException("Found symbol not in coding symbols");
      }
    }
    this.root = root.addCode(characrterSymbol,code);
  }

  @Override
  public String decode(String encodedString) throws IllegalStateException {
    return this.root.decode(encodedString);
  }

  @Override
  public String allCodes() {
    return this.root.allCodes("");
  }

  @Override
  public boolean isCodeComplete() {
    return this.root.isCodeComplete(this.codingSymbol.size());
  }
}
