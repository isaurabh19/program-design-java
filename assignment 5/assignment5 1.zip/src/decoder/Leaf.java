package decoder;

public class Leaf implements CodingTree {

  private char symbol;

  public Leaf(char symbol){
    this.symbol = symbol;
  }
  @Override
  public CodingTree addCode(char character, String symbol) {
    throw new IllegalStateException("Non Prefix code possibly passed");
  }

  @Override
  public String decode(String encodedString) {
    return this.symbol+"";
  }

  @Override
  public String allCodes(String accumulator) {
    return this.symbol+":"+accumulator+"\n";
  }

  @Override
  public boolean isCodeComplete(int codingSymbolSize) {
    return true;
  }
}
