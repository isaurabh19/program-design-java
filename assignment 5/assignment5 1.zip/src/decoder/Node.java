package decoder;

import java.util.HashMap;
import java.util.Map;

public class Node implements CodingTree {
  private Map<Character,CodingTree> children;

  public Node(){
    children = new HashMap<>();
  }
  @Override
  public CodingTree addCode(char character, String symbol) {
    if(symbol.length()==1){
      this.children.put(symbol.charAt(0),new Leaf(character));
      return this;
    }
    if(this.children.containsKey(symbol.charAt(0))){
      this.children.get(symbol.charAt(0)).addCode(character,symbol.substring(1));
    }
    else{
      this.children.put(symbol.charAt(0),new Node().addCode(character,symbol.substring(1)));
    }
    return this;
  }

  @Override
  public String decode(String encodedString)throws IllegalStateException {

    if(this.children.containsKey(encodedString.charAt(0))){
      return this.children.get(encodedString.charAt(0)).decode(encodedString.substring(1));
    }
     throw new IllegalStateException("Encoded string is incorrect");
  }

  @Override
  public String allCodes(String accumulator) {
    StringBuilder allCodesString = new StringBuilder();
    for (Map.Entry<Character,CodingTree> child:children.entrySet()) {
      allCodesString.append(child.getValue().allCodes(accumulator+child.getKey()
              .toString()));
    }
    return allCodesString.toString();
  }

  @Override
  public boolean isCodeComplete(int codingsymbolSize) {
    if(this.children.size() != codingsymbolSize){
      return false;
    }
    boolean accumulatedBoolean = true;
    for (Map.Entry<Character,CodingTree> child:children.entrySet()) {
      accumulatedBoolean &= child.getValue().isCodeComplete(codingsymbolSize);
    }
    return accumulatedBoolean;
  }
}
