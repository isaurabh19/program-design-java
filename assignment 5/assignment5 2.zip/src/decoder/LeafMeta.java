package decoder;

public class LeafMeta {
  private final int index;
  private final String leafChar;

  public LeafMeta(String leafChar, int index){
    this.index=index;
    this.leafChar=leafChar;
  }
  public int getIndex(){
    return this.index;
  }
  public String getLeafChar(){
    return this.leafChar;
  }
}
