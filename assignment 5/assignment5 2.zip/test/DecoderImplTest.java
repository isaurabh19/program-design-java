import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import decoder.Decoder;
import decoder.DecoderImpl;

public class DecoderImplTest {

  private Decoder uniDecoder;
  private Decoder binaryDecoder;
  private Decoder hexDecoder;
  private Decoder triDecoder;

  @Before
  public void setup() {
    binaryDecoder = new DecoderImpl("01");
    hexDecoder = new DecoderImpl("12345678ABCDEF");

  }

  @Test
  public void testDuplicateCodingSymbols() {

  }

  @Test
  public void testDecoderCreation() {

  }

  @Test(expected = IllegalStateException.class)
  public void testAddCodeIllegalCodeSymbol() {
    binaryDecoder.addCode('a', "1012");
  }

  @Test
  public void testFirstCodeAddCode() {

  }

  @Test
  public void testAddCode() {

  }

  @Test
  public void testAddCodeSameBranch() {
    //100 , 101
    // 123bcd 123bce
    //123bc1 123bc2
  }

  public void testAddCodeNewBranch() {
    //100 101
    //abcd abdd
    //88f 8af
  }

  @Test
  public void testAddCodeSameCodeNewSymbol() {

  }

  @Test
  public void testSingleElementCodeAddCode() {
    // a->0
    //0->a
  }

  @Test
  public void testDecodeSingleElementCode() {
    //0
    uniDecoder = new DecoderImpl("0");
    uniDecoder.addCode('c', "0");
    assertEquals("c", uniDecoder.decode("0"));

    binaryDecoder=new DecoderImpl("10");
    binaryDecoder.addCode('a',"1");
    assertEquals("a",binaryDecoder.decode("1"));
    binaryDecoder.addCode('b',"0");
    assertEquals("b",binaryDecoder.decode("0"));
  }
  @Test
  public void testDecode() {
    binaryDecoder.addCode('a', "000");
    binaryDecoder.addCode('b', "011");
    binaryDecoder.addCode('c', "11");
    binaryDecoder.addCode('d',"100");
    binaryDecoder.addCode('e',"1010");
    binaryDecoder.addCode('f',"1011");

    assertEquals("f", binaryDecoder.decode("1011"));
  }

  @Test(expected = IllegalStateException.class)
  public void testDecodeIncompleteCode() {
    // reached a node (incomplete message)
    //code doesnt exist in the tree
  }

  @Test(expected = IllegalStateException.class)
  public void testDecodeCodeNotExist() {
    //tree -> 1011
    //message -> 1010 doesn't exist
  }

  @Test(expected = IllegalStateException.class)
  public void testDecodeEmptyCode() {
    //null as well
  }

  @Test(expected = IllegalStateException.class)
  public void testDecodeOnEmptyTree() {

  }
// write test for illegal argument of decode()? e.g illegal char out of symbols?

  @Test
  public void testDecodeExistInIncompleteTree() {

  }

  @Test
  public void testIsCodeComplete() {

  }

  @Test
  public void testIsCodeCompleteSingleChild() {

  }

  @Test
  public void testIsCodeCompleteOneIncomplete() {

  }

  @Test
  public void testIsCodeCompleteFirstLevel() {

  }

  @Test
  public void testIsCodeCompleteMidLevel() {

  }

  @Test
  public void testIsCodeCompleteLastLevel() {
    binaryDecoder.addCode('a', "000");
    binaryDecoder.addCode('b', "011");
    binaryDecoder.addCode('c', "11");
    binaryDecoder.addCode('d',"100");
    binaryDecoder.addCode('e',"1010");
    binaryDecoder.addCode('f',"1011");
    binaryDecoder.addCode('g',"001");
    assertFalse(binaryDecoder.isCodeComplete());
  }
}