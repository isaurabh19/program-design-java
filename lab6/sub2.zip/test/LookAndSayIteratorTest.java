import org.junit.Before;
import org.junit.Test;

import java.math.BigInteger;

import static org.junit.Assert.*;

public class LookAndSayIteratorTest {
  private RIterator<BigInteger> rIterator;
  private RIterator<BigInteger> rIterator1;
  private RIterator<BigInteger> rIterator2;

  @Before
  public void setrIterator(){
    rIterator = new LookAndSayIterator();
    rIterator1 = new LookAndSayIterator(BigInteger.ONE);
    rIterator2 = new LookAndSayIterator(BigInteger.TEN,new BigInteger("1009988829822112"));
  }

  @Test
  public void testDefaultIterator(){
    assertTrue(rIterator.hasNext());
    assertEquals("11",rIterator.next().toString());

  }
//  @Test
//  public void testIterator1(){
//
//  }
//  @Test
//  public void testIterator2(){
//
//  }
//  @Test
//  public void testCountMoreThan9(){
//
//  }
//  @Test
//  public void testStartsWithZero(){
//
//  }
//  @Test
//  public void testContains01Only(){
//
//  }
//
//  @Test
//  public void testIteratorNextExceedsLimit(){
//
//  }
//
//  @Test
//  public void testIteratorPrevBelowLimit(){
//
//  }

}