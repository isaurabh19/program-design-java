package lookandsay;

import java.math.BigInteger;

public class LookAndSayIterator implements RIterator<BigInteger> {

  //private final BigInteger seed;
  private final BigInteger end;
  private BigInteger current;

  private void validateSeed(BigInteger seed, BigInteger end) {
    if (seed.compareTo(BigInteger.ZERO) < 0 || seed.compareTo(end) >= 0) {
      throw new IllegalStateException("Seed not valid");
    }
  }

  public LookAndSayIterator(BigInteger seed, BigInteger end) {
    validateSeed(seed, end);
    this.current = seed;
    this.end = end;
  }

  public LookAndSayIterator(BigInteger seed) {
    StringBuilder number = new StringBuilder();
    for (int i = 0; i < 100; i++) {
      number.append("9");
    }
    validateSeed(seed, new BigInteger(number.toString()));
    this.end = new BigInteger(number.toString());
    this.current = seed;
  }

  public LookAndSayIterator() {
    this.current = BigInteger.ONE;
    StringBuilder number = new StringBuilder();
    for (int i = 0; i < 100; i++) {
      number.append("9");
    }
    this.end = new BigInteger(number.toString());
  }

  //1117122113
  private BigInteger generatePrev(BigInteger current) {
    String currentNum = current.toString();
    StringBuilder result = new StringBuilder();
    for (int i = 0; i < currentNum.length(); i+=2) {
      int count = Integer.parseInt(currentNum.charAt(i) + "");
      char second = currentNum.charAt(i + 1);
      StringBuilder number = new StringBuilder();
       for (int j = 0; j < count; j++) {
        number.append(second);
      }
      result.append(number);
    }
    return new BigInteger(result.toString());
  }

  @Override
  public BigInteger prev() {
    BigInteger result = current;
    if (hasPrevious()) {
      current = generatePrev(current);
    }
    return result;
  }

  @Override
  public boolean hasPrevious() {
    return this.current.toString().length() % 2 == 0;
  }

  @Override
  public boolean hasNext() {
    return this.current.compareTo(end) < 1;
  }

  private BigInteger generateNext(BigInteger current) {
    String currentNum = current.toString();
    StringBuilder result = new StringBuilder();
    int count = 1;
    char currentChar;
    for (int i = 1; i < currentNum.length(); i++) {
      if (currentNum.charAt(i) == currentNum.charAt(i - 1)) {
        //currentChar = currentNum.charAt(0);
        count++;
      } else {
        currentChar = currentNum.charAt(i - 1);
        result.append(count).append(currentChar);
        count = 1;
      }
    }
    result.append(count).append(currentNum.charAt(currentNum.length() - 1));
    return new BigInteger(result.toString());
  }

  @Override
  public BigInteger next() {
    BigInteger result = current;
    if (hasNext()) {
      current = generateNext(current);
    }
    return result;
  }
}