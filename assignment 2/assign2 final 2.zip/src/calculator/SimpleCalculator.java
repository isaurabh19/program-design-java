package calculator;

import java.util.regex.Matcher;

public class SimpleCalculator extends AbstractCalculator implements Calculator {

  public SimpleCalculator() {
    this.currentString = "";
    this.equalsSeen = false;
  }

  private SimpleCalculator(String currentString, boolean equalsSeen) {
    this.currentString = currentString;
    this.equalsSeen = equalsSeen;
  }

  protected boolean isValidSequence(String sequence, char newChar) {
    if (sequence.isEmpty()) {
      return Character.isDigit(newChar);
    } else if (!isOperator(newChar) && (!Character.isDigit(newChar)) && (newChar != '=')) {
      return false;
    } else if (Character.isDigit(newChar)) {
      if (this.equalsSeen) {
        return false;
      } else {
        checkOperandOverflow(sequence, newChar);
      }
    }
    char lastChar = sequence.charAt(sequence.length() - 1);
    return !isOperator(lastChar) || Character.isDigit(newChar);
  }

  protected int getLastOperand(Matcher match) {
    int operand2 = 0;
    if (match.group(3) != null) {
      operand2 = getOperand(match.group(3));
    }
    return operand2;
  }

  protected String filterInputs(String sequence, char newInput) {
    if (Character.isDigit(newInput)) {
      return sequence + newInput;
    }
    return sequence;
  }

  protected String calculate(String newSequence, char newInput) {
    newSequence = evaluateExpression(newSequence);
    if (newInput != '=') {
      this.equalsSeen = false;
      newSequence = newSequence + newInput;
    } else {
      this.equalsSeen = true;
    }
    return newSequence;
  }


  protected Calculator getCalculatorInstance(String sequence) {
    return new SimpleCalculator(sequence, this.equalsSeen);
  }

  protected Calculator resetCalculator() {
    return new SimpleCalculator("", false);
  }

}


