package calculator;

public interface Calculator {

  Calculator input(char c);

  String getResult();
}