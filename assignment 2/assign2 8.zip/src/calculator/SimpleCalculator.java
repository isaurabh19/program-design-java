package calculator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SimpleCalculator implements Calculator {
  private final String currentString;
  private boolean equalsSeen;
  public SimpleCalculator() {
    this.currentString = "";
    this.equalsSeen = false;
  }
  private SimpleCalculator(String currentString, boolean equalsSeen) {
    this.currentString = currentString;
    this.equalsSeen = equalsSeen;
  }
  private boolean isOperator(char c) {
    return c == '+' || c == '-' || c == '*';
  }
  private boolean isValidSequence(String sequence, char newChar){
    if(sequence.isEmpty()) {
      return Character.isDigit(newChar);
    }
    else if (!isOperator(newChar) && (!Character.isDigit(newChar)) && (newChar != '=')) {
      return false;
    }
    else if(newChar == '=') {
      this.equalsSeen = true;
    }
    else if(Character.isDigit(newChar)) {
      if(this.equalsSeen) {
        return false;
      }
      else {
        Matcher m = getMatches(sequence + newChar);
          try {
            int operand1 = Integer.parseInt(m.group(1));
            if(m.group(3)!= null) {
              int operand2 = Integer.parseInt(m.group(3));
            }
          } catch (NumberFormatException e) {
            throw new RuntimeException("Operand Overflow");
          }
        }
      }
    char lastChar = sequence.charAt(sequence.length()-1);
    return !isOperator(lastChar) || Character.isDigit(newChar);
  }
  private Matcher getMatches(String sequence) {
    String regex = "(\\-?\\d+)([+\\-*])*(\\d+)*";
    Pattern pattern = Pattern.compile(regex);
    Matcher matcher = pattern.matcher(sequence);
    boolean b = matcher.find();
    return matcher;
  }
  private int getOperand(String operandString) {
    int operand = 0;
    try {
      operand = Integer.parseInt(operandString);
    } catch (NumberFormatException e) {
      throw new RuntimeException("Operand Overflow");
    }
    return operand;
  }
  private String solve(int operand1, int operand2, String operator) {
    String resultString = "";
    switch (operator) {
      case "+": {
        if (operand1 != 0 && operand2 != 0 && (operand1 + operand2) < 0) {
          operand1 = 0;
          operand2 = 0;
        }
        resultString = operand1 + operand2 + "";
        break;
      }
      case "-":
        if(operand1 <= 0 && (operand1 - operand2) >= 0) {
          operand1 = 0;
          operand2 = 0;
        }
        resultString = operand1 - operand2 + "";
        break;
      case "*": {
        if (operand1 != 0 && operand2 > (Integer.MAX_VALUE / Math.abs(operand1))) {
          operand1 = 0;
          operand2 = 0;
        }
        resultString = operand1 * operand2 + "";
        break;
      }
    }
    return resultString;
  }
  private String evaluateExpression(String newSequence) throws RuntimeException{
    Matcher match = getMatches(newSequence);
    int operand1 = getOperand(match.group(1));
    int operand2 = 0;
    String operator;
    if(match.group(3) != null) {
      operand2 = getOperand(match.group(3));
    }
    if(match.group(2) != null) {
      operator = match.group(2);
      //this.lastOperator = operator;
      String result = solve(operand1,operand2,operator);
      return result;
    }
    return newSequence;
  }
  @Override
  public Calculator input (char newInput) throws IllegalArgumentException {

    if(newInput == 'C'){
      return new SimpleCalculator("",false);
    }
    if(!isValidSequence(this.currentString,newInput)) {
      throw new IllegalArgumentException("Invalid sequence");
    }
    String newSequence = this.currentString;
    if(isOperator(newInput) || newInput == '='){
      newSequence = evaluateExpression(this.currentString);
    }
    if(newInput != '='){
      this.equalsSeen = false;
      newSequence = newSequence + newInput;
    }
    return new SimpleCalculator(newSequence, this.equalsSeen);
  }

  @Override
  public String getResult() {
    if(!this.currentString.isEmpty()) {
      StringBuilder filteredSequence = new StringBuilder();
      Matcher matcher = getMatches(this.currentString);
      if (matcher.group(1) != null) {
        int op1 = getOperand(matcher.group(1));
        filteredSequence.append(op1);
        if (matcher.group(2) != null) {
          String opr = matcher.group(2);
          filteredSequence.append(opr);
          if (matcher.group(3) != null) {
            int op2 = getOperand(matcher.group(3));
            filteredSequence.append(op2);
          }
        }
      }
      return filteredSequence.toString();
    }
    return this.currentString;
  }
}
