package calculator;

import java.nio.charset.CharacterCodingException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SmartCalculator implements Calculator {

  private final String currentString;
  private boolean equalsSeen = false;
  private int lastOperand;
  private String lastOperator;

  public SmartCalculator() {
    this.currentString = "";
  }

  private SmartCalculator(String newSequence, boolean equalsSeen, int lastOperand, String lastOperator) {
    this.currentString = newSequence;
    this.equalsSeen = equalsSeen;
    this.lastOperand = lastOperand;
    this.lastOperator = lastOperator;
  }

  private boolean isOperator(char c) {
    return c == '+' || c == '-' || c == '*';
  }
  private Matcher getMatches(String sequence) {
    String regex = "(\\-?\\d+)([+\\-*])*(\\d+)*";
    Pattern pattern = Pattern.compile(regex);
    Matcher matcher = pattern.matcher(sequence);
    matcher.find();
    return matcher;
  }
  private String evaluateExpression(String newSequence, char newInput) throws RuntimeException {
    Matcher match = getMatches(newSequence);
    int operand1 = getOperand(match.group(1));
    int operand2 = 0;
    String operator;
    if(match.group(3) != null) {
      operand2 = getOperand(match.group(3));
    }
    else if(newInput == '='){
      operand2 = operand1;
    }
    this.lastOperand = operand2;
    if(match.group(2) != null) {
      operator = match.group(2);
      //this.lastOperator = operator;
      String result = solve(operand1,operand2,operator);
      return result;
    }
      return newSequence;
  }

  private String filterInputs(String sequence, char newInput) {
    if (sequence.isEmpty() && !Character.isDigit(newInput)) {
        return sequence;
    }

    if (Character.isDigit(newInput)) {
      return sequence + newInput;
    }
    char lastChar = sequence.charAt(sequence.length() - 1);
    if (isOperator(newInput)) {
      this.lastOperator = newInput+"";
      this.equalsSeen = false;
      if (isOperator(lastChar)) {
        sequence = sequence.substring(0, sequence.length() - 1);
      }
    }
    return sequence;
  }
  private int getOperand(String operandString) {
    int operand = 0;
    try {
      operand = Integer.parseInt(operandString);
    } catch (NumberFormatException e) {
      throw new RuntimeException("Operand Overflow");
    }
    return operand;
  }
  private String solve(int operand1, int operand2, String operator) {
    String resultString = "";
    switch (operator) {
      case "+": {
        if (operand1 != 0 && operand2 != 0 && (operand1 + operand2) < 0) {
          operand1 = 0;
          operand2 = 0;
        }
        resultString = operand1 + operand2 + "";
        break;
      }
      case "-":
        if(operand1 < 0 && (operand1 - operand2)>0) {
          operand1 = 0;
          operand2 = 0;
        }
        resultString = operand1 - operand2 + "";
        break;
      case "*": {
        if (operand1 != 0 && operand2 > (Integer.MAX_VALUE / Math.abs(operand1))) {
          operand1 = 0;
          operand2 = 0;
        }
        resultString = operand1 * operand2 + "";
        break;
      }
    }
    return resultString;
  }
  private boolean isValidSequence(String sequence, char newInput) {
    if (!isOperator(newInput) && (!Character.isDigit(newInput)) && (newInput != '=')) {
      return false;
    }
    if(!sequence.isEmpty()) {
    Matcher m = getMatches(sequence + newInput);
      try {
        int operand1 = Integer.parseInt(m.group(1));
        if(m.group(3)!= null) {
          int operand2 = Integer.parseInt(m.group(3));
        }
      } catch (NumberFormatException e) {
        throw new RuntimeException("Operand Overflow");
      }
    }
    if (this.equalsSeen) {
      return !Character.isDigit(newInput);
    }
    return true;
  }
  @Override
  public Calculator input(char newInput) throws IllegalArgumentException, RuntimeException{
    if(newInput == 'C'){
      return new SmartCalculator("",false,0,"");
    }
    if (!isValidSequence(this.currentString,newInput)) {
      throw new IllegalArgumentException("Invalid Input Sequence");
    }
    String newSequence = filterInputs(this.currentString, newInput);
    if (!newSequence.isEmpty() && (isOperator(newInput) || newInput == '=')) {
      if(this.equalsSeen) {
        newSequence = newSequence + this.lastOperator + this.lastOperand + "";
      }
      newSequence = evaluateExpression(newSequence,newInput);
      if (newInput == '=') {
        this.equalsSeen = true;//can do this in evaluate() as well
      }
      else{
        newSequence = newSequence + newInput;
      }
    }
    return new SmartCalculator(newSequence, this.equalsSeen, this.lastOperand, this.lastOperator);
  }

  @Override
  public String getResult() {
    if(!this.currentString.isEmpty()) {
      StringBuilder filteredSequence = new StringBuilder();
      Matcher matcher = getMatches(this.currentString);
      if (matcher.group(1) != null) {
        int op1 = getOperand(matcher.group(1));
        filteredSequence.append(op1);
        if (matcher.group(2) != null) {
          String opr = matcher.group(2);
          filteredSequence.append(opr);
          if (matcher.group(3) != null) {
            int op2 = getOperand(matcher.group(3));
            filteredSequence.append(op2);
          }
        }
      }
      return filteredSequence.toString();
    }
    return this.currentString;
  }
}
