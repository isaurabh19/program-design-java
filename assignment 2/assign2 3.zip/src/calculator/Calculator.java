package calculator;

public interface Calculator {
  Calculator input(char c);
  String getResult();
}
//TODO: make classes mutable, to handle operation even after throwing error