package calculator;

import java.util.regex.Matcher;

public class SmartCalculator extends AbstractCalculator implements Calculator {
  private int lastOperand;
  private String lastOperator;

  public SmartCalculator() {
    this.currentString = "";
  }

  private SmartCalculator(String newSequence, boolean equalsSeen, int lastOperand,
                          String lastOperator) {
    this.currentString = newSequence;
    this.equalsSeen = equalsSeen;
    this.lastOperand = lastOperand;
    this.lastOperator = lastOperator;
  }

  private int getLastOperand(String operandString, int operand1) {
    int operand2;
    if (operandString != null) {
      operand2 = getOperand(operandString);
    } else {
      operand2 = operand1;
    }
    this.lastOperand = operand2;
    return operand2;
  }

  private String evaluateExpression(String newSequence, char newInput) throws RuntimeException {
    Matcher match = getMatches(newSequence);
    int operand1 = getOperand(match.group(1));
    int operand2 = 0;
    String operator;
    if (match.group(3) != null) {
      operand2 = getOperand(match.group(3));
    } else if (newInput == '=') {
      operand2 = operand1;
    }
    this.lastOperand = operand2;
    if (match.group(2) != null) {
      operator = match.group(2);
      //this.lastOperator = operator;
      String result = solve(operand1, operand2, operator);
      return result;
    }
    return newSequence;
  }

  protected String filterInputs(String sequence, char newInput) {
    if (sequence.isEmpty() && !Character.isDigit(newInput)) {
      return sequence;
    }
    if (Character.isDigit(newInput)) {
      return sequence + newInput;
    }
    char lastChar = sequence.charAt(sequence.length() - 1);
    if (isOperator(newInput)) {
      this.lastOperator = newInput + "";
      this.equalsSeen = false;
      if (isOperator(lastChar)) {
        sequence = sequence.substring(0, sequence.length() - 1);
      }
    }
    return sequence;
  }

  protected boolean isValidSequence(String sequence, char newInput) {
    if (!isOperator(newInput) && (!Character.isDigit(newInput)) && (newInput != '=')) {
      return false;
    }
    if (!sequence.isEmpty()) {
      checkOperandOverflow(sequence, newInput);
    }
    if (this.equalsSeen) {
      return !Character.isDigit(newInput);
    }
    return true;
  }

  protected String calculate(String newSequence, char newInput) {
    if (!newSequence.isEmpty()) {
      if (this.equalsSeen) {
        newSequence = newSequence + this.lastOperator + this.lastOperand + "";
      }
      newSequence = evaluateExpression(newSequence, newInput);
      if (newInput == '=') {
        this.equalsSeen = true;//can do this in evaluate() as well
      } else {
        newSequence = newSequence + newInput;
      }
    }
    return newSequence;
  }

  protected Calculator getCalculatorInstance(String sequence) {
    return new SmartCalculator(sequence, this.equalsSeen, this.lastOperand, this.lastOperator);
  }

  protected Calculator resetCalculator() {
    return new SmartCalculator("", false, 0, "");
  }

}
