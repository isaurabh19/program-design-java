package calculator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

abstract class AbstractCalculator implements Calculator {
  protected String currentString;
  protected boolean equalsSeen;

  protected boolean isOperator(char c) {
    return c == '+' || c == '-' || c == '*';
  }

  protected Matcher getMatches(String sequence) {
    String regex = "(\\-?\\d+)([+\\-*])*(\\d+)*";
    Pattern pattern = Pattern.compile(regex);
    Matcher matcher = pattern.matcher(sequence);
    matcher.find();
    return matcher;
  }

  protected int getOperand(String operandString) {
    int operand = 0;
    try {
      operand = Integer.parseInt(operandString);
    } catch (NumberFormatException e) {
      throw new RuntimeException("Operand Overflow");
    }
    return operand;
  }

  protected String solve(int operand1, int operand2, String operator) {
    String resultString = "";
    switch (operator) {
      case "+": {
        if (operand1 != 0 && operand2 != 0 && (operand1 + operand2) < 0) {
          operand1 = 0;
          operand2 = 0;
        }
        resultString = operand1 + operand2 + "";
        break;
      }
      case "-":
        if (operand1 < 0 && (operand1 - operand2) > 0) {
          operand1 = 0;
          operand2 = 0;
        }
        resultString = operand1 - operand2 + "";
        break;
      case "*": {
        if (operand1 != 0 && operand2 > (Integer.MAX_VALUE / Math.abs(operand1))) {
          operand1 = 0;
          operand2 = 0;
        }
        resultString = operand1 * operand2 + "";
        break;
      }
      default:
        resultString = "";
        break;
    }
    return resultString;
  }

  protected void checkOperandOverflow(String sequence, char newInput) {

    Matcher m = getMatches(sequence + newInput);
    try {
      int operand1 = Integer.parseInt(m.group(1));
      if (m.group(3) != null) {
        int operand2 = Integer.parseInt(m.group(3));
      }
    } catch (NumberFormatException e) {
      throw new RuntimeException("Operand Overflow");
    }

  }

  abstract Calculator resetCalculator();

  abstract boolean isValidSequence(String sequence, char newInput);

  abstract String filterInputs(String sequence, char newInput);

  abstract String calculate(String sequence, char newInput);

  abstract Calculator getCalculatorInstance(String sequence);

  @Override
  public Calculator input(char newInput) throws IllegalArgumentException {
    if (newInput == 'C') {
      return this.resetCalculator();
    }
    if (!isValidSequence(this.currentString, newInput)) {
      throw new IllegalArgumentException("Invalid Input Sequence");
    }
    String newSequence = filterInputs(this.currentString, newInput);
    if (isOperator(newInput) || newInput == '=') {
      newSequence = calculate(newSequence, newInput);
    }
    return this.getCalculatorInstance(newSequence);
  }

  public String getResult() {
    if (!this.currentString.isEmpty()) {
      StringBuilder filteredSequence = new StringBuilder();
      Matcher matcher = getMatches(this.currentString);
      if (matcher.group(1) != null) {
        int op1 = getOperand(matcher.group(1));
        filteredSequence.append(op1);
        if (matcher.group(2) != null) {
          String opr = matcher.group(2);
          filteredSequence.append(opr);
          if (matcher.group(3) != null) {
            int op2 = getOperand(matcher.group(3));
            filteredSequence.append(op2);
          }
        }
      }
      return filteredSequence.toString();
    }
    return this.currentString;
  }
}

