Steps to run the jar:
1. Navigate to the folder where the 'assignment-8-2.jar' resides.
2. take the jar outside of res and run the jar. where the jar is that folder should contain res folder
with the below structure:
/persisted/portfolio
/persisted/strategy
Copy the folder 'stockinfo' where the jar resides if it doesn't already exist.
* dir:stockinfo is necessary to run the jar.
3. Copy config.properties file to the location of jar.(where the jar will run)
4. Run 'java -jar assignment-8-2.jar -view gui' or -view console

Refer to command package or commands.txt file for commands and their syntax.