package freecell.model;

import java.util.List;

/**
 *
 */
public class FreecellMultiMoveModel extends AbstractFreecellModel implements
        FreecellOperations<Cards> {

  private FreecellMultiMoveModel(int cascadeSize, int openSize) {
    super(cascadeSize,openSize);
  }

  /**
   *
   * @return
   */
  public static FreecellOperationsBuilder getBuilder(){
    return new FreecellMultiMoveOperationsBuilderImpl();
  }

  @Override
  protected Pile getCascadePile(int cascadeSize, List<Cards> deck) {
    return new CascadeMultiMove(cascadeSize, deck);
  }

  /**
   *
   */
  public static class FreecellMultiMoveOperationsBuilderImpl extends
          AbstractFreecellOperationsBuilder {

    private FreecellMultiMoveOperationsBuilderImpl() {
      super();
    }

    @Override
    protected FreecellOperations<Cards> getModelInstance(int cascadeSize, int openSize) {
      return new FreecellMultiMoveModel(cascadeSize, openSize);
    }
  }
}
