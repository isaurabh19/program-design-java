import org.junit.Before;
import org.junit.Test;

import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import freecell.controller.IFreecellController;
import freecell.model.Cards;
import freecell.controller.FreecellController;
import freecell.model.FreecellModel;
import freecell.model.FreecellMultiMoveModel;
import freecell.model.FreecellOperations;

import static org.junit.Assert.*;

public class FreecellControllerTest {

  private IFreecellController<Cards> freecellController;
  private FreecellOperations<Cards> freecellMultiMoveModel;
  //private FreecellOperations<Cards> freecellMultiMoveModel;
  private final String[] deckOfCardsArray = {"A♥", "2♥", "3♥", "4♥", "5♥", "6♥", "7♥", "8♥", "9♥",
          "10♥", "J♥", "Q♥", "K♥", "A♦", "2♦", "3♦", "4♦", "5♦", "6♦", "7♦", "8♦", "9♦", "10♦",
          "J♦", "Q♦", "K♦", "A♠", "2♠", "3♠", "4♠", "5♠", "6♠", "7♠", "8♠", "9♠", "10♠", "J♠",
          "Q♠", "K♠", "A♣", "2♣", "3♣", "4♣", "5♣", "6♣", "7♣", "8♣", "9♣", "10♣", "J♣", "Q♣", "K♣"};

  @Before
  public void setFreecellController(){
    freecellMultiMoveModel = FreecellMultiMoveModel.getBuilder().cascades(52).opens(52).build();
    //freecellMultiMoveModel = FreecellMultiMoveModel.getBuilder().build();
  }
  @Test
  public void testInvalidMoveWrongPileNumber(){
    Reader reader = new StringReader("C53 1 F4 Q\n C1 1 F4\n");
    StringBuffer stringBuffer =  new StringBuffer();
    freecellController = new FreecellController(reader,stringBuffer);
    freecellController.playGame(freecellMultiMoveModel.getDeck(), freecellMultiMoveModel,false);
    List<String> gameState = new ArrayList<>();
    for (int i = 0; i < 4; i++) {
      gameState.add("F" + (i + 1) + ":");
    }
    for (int i = 0; i < 52; i++) {
      gameState.add("O" + (i + 1) + ":");
    }
    for (int i = 0; i < 52; i++) {
      gameState.add("C" + (i + 1) + ": " + deckOfCardsArray[i]);
    }
    assertEquals(getGameStateStartTestString()+"\nInvalid Move. Try again.\n"+String
            .join("\n",gameState)+"\nGame quit prematurely.",stringBuffer.toString());
  }

  @Test
  public void testInvalidMoveWrongCardIndex(){
    Reader reader = new StringReader("C52 2 F4 q\n");
    StringBuffer stringBuffer =  new StringBuffer();
    freecellController = new FreecellController(reader,stringBuffer);
    freecellController.playGame(freecellMultiMoveModel.getDeck(), freecellMultiMoveModel,false);
    //TODO check if getGameState is to be called even after invalid move.
    assertEquals(getGameStateStartTestString()+"\nInvalid Move. Try again.\n"
            +getGameStateStartTestString()+"\nGame quit prematurely.",stringBuffer.toString());

  }
  @Test
  public void testInvalidMultiMoveToOpen(){
    Reader reader = new StringReader("C1 1 C28\nC28 1 O2 q");
    StringBuffer stringBuffer = new StringBuffer();
    freecellController = new FreecellController(reader,stringBuffer);
    freecellController.playGame(freecellMultiMoveModel.getDeck(), freecellMultiMoveModel,false);
    List<String> gameState = new ArrayList<>();
    for (int i = 0; i < 4; i++) {
      gameState.add("F" + (i + 1) + ":");
    }
    for (int i = 0; i < 52; i++) {
      gameState.add("O" + (i + 1) + ":");
    }
    gameState.add("C1:");
    for (int i = 1; i < 27; i++) {
      gameState.add("C" + (i + 1) + ": " + deckOfCardsArray[i]);
    }
    gameState.add("C28: 2♠, A♥");
    for (int i = 28; i < 52; i++) {
      gameState.add("C" + (i + 1) + ": " + deckOfCardsArray[i]);
    }

    assertEquals(getGameStateStartTestString()+"\n"+String.join("\n",gameState)
            +"\nInvalid Move. Try again.\n"+String.join("\n",gameState)
            +"\nGame quit prematurely.", stringBuffer.toString());

  }
  @Test
  public void testInvalidMultiMoveToFoundation(){
    Reader reader = new StringReader("C1 1 C28\nC28 1 F2 q");
    StringBuffer stringBuffer = new StringBuffer();
    freecellController = new FreecellController(reader,stringBuffer);
    freecellController.playGame(freecellMultiMoveModel.getDeck(), freecellMultiMoveModel,false);

    List<String> gameState = new ArrayList<>();
    for (int i = 0; i < 4; i++) {
      gameState.add("F" + (i + 1) + ":");
    }
    for (int i = 0; i < 52; i++) {
      gameState.add("O" + (i + 1) + ":");
    }
    gameState.add("C1:");
    for (int i = 1; i < 27; i++) {
      gameState.add("C" + (i + 1) + ": " + deckOfCardsArray[i]);
    }
    gameState.add("C28: 2♠, A♥");
    for (int i = 28; i < 52; i++) {
      gameState.add("C" + (i + 1) + ": " + deckOfCardsArray[i]);
    }
    assertEquals(getGameStateStartTestString()+"\n"+String.join("\n",gameState)
            +"\nInvalid Move. Try again.\n"+String.join("\n",gameState)
            +"\nGame quit prematurely.", stringBuffer.toString());

  }@Test
  public void testInvalidMoveWrongPileType(){
    Reader reader = new StringReader("O1 2 F4 q\n");
    StringBuffer stringBuffer =  new StringBuffer();
    freecellController = new FreecellController(reader,stringBuffer);
    freecellController.playGame(freecellMultiMoveModel.getDeck(), freecellMultiMoveModel,false);
    assertEquals(getGameStateStartTestString()+"\nInvalid Move. Try again.\n"+getGameStateStartTestString()+"\nGame quit prematurely.",stringBuffer.toString());
    List<String> gameState = new ArrayList<>();
    gameState.add("F1: A♥, 2♥");
    for (int i = 1; i < 4; i++) {
      gameState.add("F" + (i + 1) + ":");
    }
    for (int i = 0; i < 52; i++) {
      gameState.add("O" + (i + 1) + ":");
    }
    gameState.add("C1:");
    gameState.add("C2:");
    for (int i = 2; i < 52; i++) {
      gameState.add("C" + (i + 1) + ": " + deckOfCardsArray[i]);
    }

    reader = new StringReader("F1 1 C2 q");
    stringBuffer = new StringBuffer();
    freecellController = new FreecellController(reader,stringBuffer);
    freecellController.playGame(freecellMultiMoveModel.getDeck(), freecellMultiMoveModel,false);
    assertEquals(getGameStateStartTestString()+"\nInvalid Move. Try again.\n"
            +getGameStateStartTestString()+"\nGame quit prematurely.",stringBuffer.toString());
  }

  @Test
  public void testIncorrectFirstValueLowerCase(){
    Reader reader = new StringReader("c1 x1 C1 1 F4 q\n");
    StringBuffer stringBuffer =  new StringBuffer();
    freecellController = new FreecellController(reader,stringBuffer);
    freecellController.playGame(freecellMultiMoveModel.getDeck(), freecellMultiMoveModel,false);
    List<String> gameState = new ArrayList<>();
    for (int i = 0; i < 3; i++) {
      gameState.add("F" + (i + 1) + ":");
    }
    gameState.add("F4: A♥");
    for (int i = 0; i < 52; i++) {
      gameState.add("O" + (i + 1) + ":");
    }
    gameState.add("C1:");
    for (int i = 1; i < 52; i++) {
      gameState.add("C" + (i + 1) + ": " + deckOfCardsArray[i]);
    }
    assertEquals(getGameStateStartTestString()+"\nIncorrect First Input. Enter Again.\n"+"Incorrect First Input. " +
            "Enter Again.\n" +String.join("\n",gameState) + "\nGame quit prematurely."
            ,stringBuffer.toString());

  }

  @Test
  public void testIncorrectSecondValue(){
    Reader reader = new StringReader("c1 CY1 C1 1100000000212121000 1 f4 g4 F4 q\n");
    StringBuffer stringBuffer =  new StringBuffer();
    freecellController = new FreecellController(reader,stringBuffer);
    freecellController.playGame(freecellMultiMoveModel.getDeck(), freecellMultiMoveModel,false);
    List<String> gameState = new ArrayList<>();
    for (int i = 0; i < 3; i++) {
      gameState.add("F" + (i + 1) + ":");
    }
    gameState.add("F4: A♥");
    for (int i = 0; i < 52; i++) {
      gameState.add("O" + (i + 1) + ":");
    }
    gameState.add("C1:");
    for (int i = 1; i < 52; i++) {
      gameState.add("C" + (i + 1) + ": " + deckOfCardsArray[i]);
    }
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getGameStateStartTestString()).append("\n");
    for(int i=0;i<2;i++){
      stringBuilder.append("Incorrect First Input. Enter Again.\n");
    }
    for(int i=0;i<1;i++){
      stringBuilder.append("Incorrect Second Input. Enter Again.\n");
    }
    for(int i=0;i<2;i++){
      stringBuilder.append("Incorrect Third Input. Enter Again.\n");
    }
    assertEquals(stringBuilder.toString()+String.join("\n",gameState)+"\nGame quit prematurely.",
            stringBuffer.toString());
  }

  private String getGameStateStartTestString(){
    List<String> gameState = new ArrayList<>();
    for (int i = 0; i < 4; i++) {
      gameState.add("F" + (i + 1) + ":");
    }
    for(int i =0; i<52;i++){
      gameState.add("O"+(i+1)+":");
    }
    for (int i = 0; i < 52; i++) {
      gameState.add("C" + (i + 1) + ": " + deckOfCardsArray[i]);
    }
    return String.join("\n",gameState);
  }
  @Test
  public void testQuitSecondArgument(){
    Reader reader = new StringReader("C1 q\n");
    StringBuffer stringBuffer =  new StringBuffer();
    freecellController = new FreecellController(reader,stringBuffer);
    freecellController.playGame(freecellMultiMoveModel.getDeck(), freecellMultiMoveModel,false);
    assertEquals(getGameStateStartTestString()+"\nGame quit prematurely.",stringBuffer.toString());
  }

  @Test
  public void testQuitIgnoresNext(){
    Reader reader = new StringReader("C1 1 C28\nC28 1 C3\nC3 1 C30 q\nC30 1 C5");
    StringBuffer stringBuffer =  new StringBuffer();
    freecellController = new FreecellController(reader,stringBuffer);
    freecellController.playGame(freecellMultiMoveModel.getDeck(), freecellMultiMoveModel,false);

  }


}