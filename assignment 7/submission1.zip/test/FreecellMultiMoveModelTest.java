import org.junit.Before;
import org.junit.Test;

import java.util.List;

import freecell.model.Cards;
import freecell.model.CascadePile;
import freecell.model.FreecellModel;
import freecell.model.FreecellMultiMoveModel;
import freecell.model.FreecellOperations;
import freecell.model.PileType;

import static org.junit.Assert.assertEquals;

public class FreecellMultiMoveModelTest {
  private FreecellOperations<Cards> defaultFreecellGame;
  private FreecellOperations<Cards> freecellGameO8C8;
  private FreecellOperations<Cards> freecellGameLocal;

  @Before
  public void setup() {
    defaultFreecellGame = FreecellMultiMoveModel.getBuilder().build();

    freecellGameO8C8 = FreecellMultiMoveModel.getBuilder().opens(8).cascades(8).build();
    List<Cards> newDeck = freecellGameO8C8.getDeck();
    freecellGameO8C8.startGame(newDeck, false);
  }

  @Test
  public void testSimpleMultiMove() {
    assertEquals("", defaultFreecellGame.getGameState());
  }

  @Test
  public void test1() {
    freecellGameLocal = FreecellMultiMoveModel.getBuilder().opens(1).cascades(52).build();
    List<Cards> newDeck = freecellGameLocal.getDeck();
    freecellGameLocal.startGame(newDeck, false);

    freecellGameLocal.move(PileType.CASCADE, 0, 0, PileType.CASCADE, 27);
    freecellGameLocal.move(PileType.CASCADE, 27, 0, PileType.CASCADE, 15);
    freecellGameLocal.move(PileType.CASCADE, 15, 0, PileType.CASCADE, 29);
    assertEquals("", freecellGameLocal.getGameState());
  }
}