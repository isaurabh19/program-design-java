package freecell.model;

abstract class AbstractFreecellOperationsBuilder implements FreecellOperationsBuilder{
  protected int openSize;
  protected int cascadeSize;
  @Override
  public FreecellOperationsBuilder cascades(int cascadeSize) {
    if (cascadeSize < 4) {
      throw new IllegalArgumentException("Cascade deck size cannot be " + cascadeSize +
              ". It should be at least 4.");
    }
    this.cascadeSize = cascadeSize;
    return this;
  }

  @Override
  public FreecellOperationsBuilder opens(int openSize) {
    if (openSize < 1) {
      throw new IllegalArgumentException("Open deck size cannot be " + openSize + ". " +
              "It should be at least 1");
    }
    this.openSize = openSize;
    return this;
  }

  @Override
  public FreecellOperations<Cards> build() {
    return this.getModelInstance(this.cascadeSize,this.openSize);
  }
  protected abstract  FreecellOperations<Cards> getModelInstance(int cascadeSize, int openSize);
}
