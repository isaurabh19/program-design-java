import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import freecell.controller.FreecellController;
import freecell.controller.IFreecellController;
import freecell.model.Cards;
import freecell.model.FreecellModel;
import freecell.model.FreecellOperations;

import static java.lang.Integer.parseInt;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.fail;

public class NachiketLiteralTextTests {
  private FreecellOperations<Cards> freecellGame;

  @Before
  public void setup() {
    freecellGame = FreecellModel.getBuilder().build();
    List<Cards> newDeck = freecellGame.getDeck();
    freecellGame.startGame(newDeck, false);
  }

  @Test
  public void testInvalidBuildForMultipleCascadeMove1() {
    //Multiple cards list whose build is invalid.
    //Get state and see if game over
  }

  @Test
  public void testInvalidBuildAtDestination2() {
    //Multiple cards list such that the order at destination is invalid.
    //Check game state
  }

  @Test
  public void testNotEnoughEmptyPiles3() {
    try {
      fail();
    } catch (IllegalArgumentException e) {
      //check game state
      //Check gameover
      assertEquals(e.getMessage(), "");
    }
  }

  @Test
  public void testSuccessfulMultipleMove3() {
    //check game state.
  }

//  @Test
//  public void testShuffleTrue4() {
//    IFreecellController<Cards> freecellController = new FreecellController(System.in, System.out);
//    //freecellController.playGame(deck, model, true);
//    //getState to test the shuffle.
//  }
//
//  @Test
//  public void testShuffleFalse4() {
//    IFreecellController<Cards> freecellController = new FreecellController(System.in, System.out);
//    //freecellController.playGame(deck, model, false);
//    //getState to test the shuffle.
//  }
//
//  @Test
//  public void testShuffleNull4() {
//    IFreecellController<Cards> freecellController = new FreecellController(System.in, System.out);
//    try {
//      //freecellController.playGame(deck, model, null);
//      fail();
//    } catch (IllegalArgumentException e) {
//      assertEquals("", e.getMessage());
//    }
//    //getState to test the shuffle.
//  }

  @Test
  public void testInvalidDeck5a() {
    try {
      //test the invalid deck
      fail();
    } catch (IllegalArgumentException e) {
      assertEquals("", e.getMessage());
    }
  }

  @Test
  public void testInvalidModel5a() {
    try {
      //test the invalid model
      fail();
    } catch (IllegalArgumentException e) {
      assertEquals("", e.getMessage());
    }
  }

  @Test
  public void testControllerCantRecieveInput5b() {
    try {
      //
      fail();
    } catch (IllegalStateException e) {
      assertEquals("", e.getMessage());
    }
  }

  @Test
  public void test() {
    List<Integer> tryList = new ArrayList<>();
    tryList.add(1);
    tryList.add(2);
    tryList.add(3);
    for (int i = 0; i <= tryList.size(); i++) {
      int j = i + 1;
      if (j < tryList.size()) {
        System.out.println(tryList.get(i) + ":" + tryList.get(j));
      }
    }
  }
   @Test
   public void test1(){
    List<Integer> test = new ArrayList<>();
    test.add(1);

    List<Integer> split = test.subList(1,1);
     System.out.println(split.toString());
   }
    @Test
    public void testControllerCantProduceOutput5b () {
      try {
        //
        fail();
      } catch (IllegalStateException e) {
        assertEquals("", e.getMessage());
      }
    }

    @Test
    public void testFreecellControllerAppendableNull6 () {
      assertEquals("", "   ");
    }

    @Test
    public void testFreecellControllerReadableNull6 () {
      assertEquals("", "   ");

    }

    @Test
    public void testMoveWhenSequenceIsNotEndingWithNewLine7 () {
      //when the sequence of inputs does not end with newline.
    }

    @Test
    public void testGameIsWon8 () {
      //Transmit the final game state.
      //Transmit message of "Game Over"
      //End game play
    }

    @Test
    public void testWhenOtherDeckIsEntered9 () {

    }

    @Test
    public void testQuittingOfGame10 () {

    }

    @Test
    public void testLetterOtherThanCFO11a () {
      //When the letter is anything apart from CFO
    }

    @Test
    public void testPileNumberIncorret11b () {
      //When the pile number is invalid, ie, apart from a number. - Cq 3 F2, C4 5 Fw
    }

    @Test
    public void testCardIndexIncorrectly11c () {
      //When the card index is incorrect.
    }

    @Test
    public void testDestinationPileNumberIncorrect11d () {

    }

    @Test
    public void testInvalidMove12 () {
      //When model tells its an invalid move, append "Invalid move. Try again. +suitable message"
    }

    @Test
    public void testEndOfGame13 () {
      //Try to test if the game ends only when the game is won or q is pressed.
    }

    @Test
    public void testSample () {
      String str = "C3 4 F4";
      Scanner scan = new Scanner(str);
      String sourcePile, destinationPile, cardIndex;
      int srcPN, destPN;
      String source = scan.next();
      switch (source.charAt(0)) {
        case 'C':
          sourcePile = "Cascade";
          srcPN = parseInt(source.substring(1));
          System.out.println(sourcePile + " and " + srcPN);
          break;
        case 'F':


          break;
        case 'O':

          break;
        default://Enter valid letter.
      }
    }
  }