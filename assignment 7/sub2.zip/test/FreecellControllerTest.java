import org.junit.Before;
import org.junit.Test;

import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import freecell.controller.IFreecellController;
import freecell.model.Cards;
import freecell.controller.FreecellController;
import freecell.model.FreecellModel;
import freecell.model.FreecellMultiMoveModel;
import freecell.model.FreecellOperations;

import static org.junit.Assert.*;

public class FreecellControllerTest {

  private IFreecellController<Cards> freecellController;
  private FreecellOperations<Cards> freecellModel;
  private FreecellOperations<Cards> freecellMultiMoveModel;
  private final String[] deckOfCardsArray = {"A♥", "2♥", "3♥", "4♥", "5♥", "6♥", "7♥", "8♥", "9♥",
          "10♥", "J♥", "Q♥", "K♥", "A♦", "2♦", "3♦", "4♦", "5♦", "6♦", "7♦", "8♦", "9♦", "10♦",
          "J♦", "Q♦", "K♦", "A♠", "2♠", "3♠", "4♠", "5♠", "6♠", "7♠", "8♠", "9♠", "10♠", "J♠",
          "Q♠", "K♠", "A♣", "2♣", "3♣", "4♣", "5♣", "6♣", "7♣", "8♣", "9♣", "10♣", "J♣", "Q♣", "K♣"};

  @Before
  public void setFreecellController(){
    freecellModel = FreecellModel.getBuilder().cascades(52).opens(52).build();
    freecellMultiMoveModel = FreecellMultiMoveModel.getBuilder().build();
  }
  @Test
  public void testInvalidMoveWrongPileNumber(){
    Reader reader = new StringReader("C53 1 F4\n C1 1 F4\n");
    StringBuffer stringBuffer =  new StringBuffer();
    freecellController = new FreecellController(reader,stringBuffer);
    freecellController.playGame(freecellModel.getDeck(),freecellModel,false);
    List<String> gameState = new ArrayList<>();
    for (int i = 0; i < 3; i++) {
      gameState.add("F" + (i + 1) + ":");
    }
    gameState.add("F4: A♥");
    for (int i = 0; i < 52; i++) {
      gameState.add("O" + (i + 1) + ":");
    }
    gameState.add("C1:");
    for (int i = 1; i < 52; i++) {
      gameState.add("C" + (i + 1) + ": " + deckOfCardsArray[i]);
    }
    assertEquals("Invalid Move. Try again. Invalid Source\n"+String
            .join("\n",gameState),stringBuffer.toString());
  }

  @Test
  public void testInvalidMoveWrongCardIndex(){
    Reader reader = new StringReader("C52 2 F4\n");
    StringBuffer stringBuffer =  new StringBuffer();
    freecellController = new FreecellController(reader,stringBuffer);
    freecellController.playGame(freecellModel.getDeck(),freecellModel,false);
    //TODO check if getGameState is to be called even after invalid move.
    assertEquals("Invalid Move.Try again.",stringBuffer.toString());

  }
  @Test
  public void testInvalidMultiMoveToOpen(){
    Reader reader = new StringReader("C1 1 C28\nC28 1 O2");
    StringBuffer stringBuffer = new StringBuffer();
    freecellController = new FreecellController(reader,stringBuffer);
    freecellController.playGame(freecellModel.getDeck(),freecellModel,false);
    List<String> gameState = new ArrayList<>();
    for (int i = 0; i < 4; i++) {
      gameState.add("F" + (i + 1) + ":");
    }
    for (int i = 0; i < 52; i++) {
      gameState.add("O" + (i + 1) + ":");
    }
    gameState.add("C1:");
    for (int i = 1; i < 27; i++) {
      gameState.add("C" + (i + 1) + ": " + deckOfCardsArray[i]);
    }
    gameState.add("C28: 2♠, A♥");
    for (int i = 28; i < 52; i++) {
      gameState.add("C" + (i + 1) + ": " + deckOfCardsArray[i]);
    }

    assertEquals(String.join("\n",gameState)+"\nInvalid Move.Try again.",
            stringBuffer.toString());

  }
  @Test
  public void testInvalidMultiMoveToFoundation(){
    Reader reader = new StringReader("C1 1 C28\nC28 1 F2");
    StringBuffer stringBuffer = new StringBuffer();
    freecellController = new FreecellController(reader,stringBuffer);
    freecellController.playGame(freecellModel.getDeck(),freecellModel,false);

    List<String> gameState = new ArrayList<>();
    for (int i = 0; i < 4; i++) {
      gameState.add("F" + (i + 1) + ":");
    }
    for (int i = 0; i < 52; i++) {
      gameState.add("O" + (i + 1) + ":");
    }
    gameState.add("C1:");
    for (int i = 1; i < 27; i++) {
      gameState.add("C" + (i + 1) + ": " + deckOfCardsArray[i]);
    }
    gameState.add("C28: 2♠, A♥");
    for (int i = 28; i < 52; i++) {
      gameState.add("C" + (i + 1) + ": " + deckOfCardsArray[i]);
    }
    assertEquals(String.join("\n",gameState)+"\nInvalid Move.Try again.",
            stringBuffer.toString());

  }@Test
  public void testInvalidMoveWrongPileType(){
    Reader reader = new StringReader("O1  2 F4\n");
    StringBuffer stringBuffer =  new StringBuffer();
    freecellController = new FreecellController(reader,stringBuffer);
    freecellController.playGame(freecellModel.getDeck(),freecellModel,false);
    assertEquals("Invalid Move.Try again.",stringBuffer.toString());
    List<String> gameState = new ArrayList<>();
    gameState.add("F1: A♥, 2♥");
    for (int i = 1; i < 4; i++) {
      gameState.add("F" + (i + 1) + ":");
    }
    for (int i = 0; i < 52; i++) {
      gameState.add("O" + (i + 1) + ":");
    }
    gameState.add("C1:");
    gameState.add("C2:");
    for (int i = 2; i < 52; i++) {
      gameState.add("C" + (i + 1) + ": " + deckOfCardsArray[i]);
    }

    reader = new StringReader("C1 1 F1\nC2 1 F1\nF1 1 C2");
    stringBuffer = new StringBuffer();
    freecellController = new FreecellController(reader,stringBuffer);
    freecellController.playGame(freecellModel.getDeck(),freecellModel,false);
    assertEquals(String.join("\n",gameState)+"\nInvalid Move.Try again.",
            stringBuffer.toString());

  }

  @Test
  public void testIncorrectFirstValueLowerCase(){
    Reader reader = new StringReader("c1 x1 C1 1 F4\n");
    StringBuffer stringBuffer =  new StringBuffer();
    freecellController = new FreecellController(reader,stringBuffer);
    freecellController.playGame(freecellModel.getDeck(),freecellModel,false);
    List<String> gameState = new ArrayList<>();
    for (int i = 0; i < 3; i++) {
      gameState.add("F" + (i + 1) + ":");
    }
    gameState.add("F4: A♥");
    for (int i = 0; i < 52; i++) {
      gameState.add("O" + (i + 1) + ":");
    }
    gameState.add("C1:");
    for (int i = 1; i < 52; i++) {
      gameState.add("C" + (i + 1) + ": " + deckOfCardsArray[i]);
    }
    assertEquals("Incorrect First Input. Enter again.\n"+"Incorrect First Input. " +
            "Enter again.\n" +String.join("\n",gameState),stringBuffer.toString());

  }

  @Test
  public void testIncorrectSecondValue(){
    Reader reader = new StringReader("c1 CY1 C1 -1 1100000000212121000 1 f4 g4 F4\n");
    StringBuffer stringBuffer =  new StringBuffer();
    freecellController = new FreecellController(reader,stringBuffer);
    freecellController.playGame(freecellModel.getDeck(),freecellModel,false);
    List<String> gameState = new ArrayList<>();
    for (int i = 0; i < 3; i++) {
      gameState.add("F" + (i + 1) + ":");
    }
    gameState.add("F4: A♥");
    for (int i = 0; i < 52; i++) {
      gameState.add("O" + (i + 1) + ":");
    }
    gameState.add("C1:");
    for (int i = 1; i < 52; i++) {
      gameState.add("C" + (i + 1) + ": " + deckOfCardsArray[i]);
    }
    StringBuilder stringBuilder = new StringBuilder();
    for(int i=0;i<2;i++){
      stringBuilder.append("Incorrect First Input. Enter again.\n");
    }
    for(int i=0;i<2;i++){
      stringBuilder.append("Incorrect Second Input. Enter again.\n");
    }
    for(int i=0;i<2;i++){
      stringBuilder.append("Incorrect Third Input. Enter again.\n");
    }
    assertEquals(stringBuilder.toString()+String.join("\n",gameState),
            stringBuffer.toString());
  }

  @Test
  public void testQuitSecondArgument(){
    Reader reader = new StringReader("C1 q F1\n");
    StringBuffer stringBuffer =  new StringBuffer();
    freecellController = new FreecellController(reader,stringBuffer);
    freecellController.playGame(freecellModel.getDeck(),freecellModel,false);
    assertEquals("Game quit prematurely.",stringBuffer.toString());
  }

  //TODO throw error?
  @Test(expected = IllegalStateException.class)
  public void  testMissingInput(){

  }


}